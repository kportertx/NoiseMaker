#ifndef PYAUDIO_STREAM_HPP
#define PYAUDIO_STREAM_HPP

#include <Python.h>
#include <audiere.h>

extern PyTypeObject audiere_OutputStreamType;

struct audiere_OutputStreamObject {
  PyObject_HEAD
  audiere::OutputStream* stream;
};

static char OutPutStream_doc[] = 
"A pyAudiere output stream. This object is returned by the AudioDevice\n\
methods, and it contains various methods and properties to control \n\
different aspects of playback.\n\n\
OutputStream methods and properties\n\n\
  play()\n\
    Begins playback of the stream. Does nothing if stream is playing.\n\n\
  pause()\n\
    Stops playback of the stream, but does not reset.\n\n\
  stop()\n\
    Stops playback, and resets the stream to the beginning.\n\n\
  reset()\n\
    Resets the stream to the beginning.\n\n\
  field: playing :: boolean\n\
    Gets or sets whether the stream is playing. 1=playing, 0=not playing.\n\n\
  field: repeating :: boolean\n\
    Gets or sets whether the stream will repeat. If 1, when the end of \n\
    the stream is hit, the stream starts playback from the beginning.\n\n\
  field: volume :: floating point number\n\
    Gets or sets the current volume of the stream. 1 is maximum, 0 is\n\
    silence.\n\n\
  field: pan :: floating point number\n\
    Gets or sets the current pan of the stream. 0 is centered, -1 is\n\
    all of the way to the left, and 1 is to the right.\n\n\
  field: pitchshift :: floating point number\n\
    Gets or sets the current pitch shift.  1 is no shift, 2 is an octave\n\
    higher, and 0.5 is an octave lower.\n\n\
  readonly field: seekable :: boolean\n\
    If this is true, the following fields are applicable.\n\n\
  readonly field: length :: integer\n\
    The number of samples within this stream.\n\n\
  field: position :: integer\n\
    Gets or sets the current position of the play cursor in the stream.\n";

static char OutputStream_Play_doc[] = 
"Play an output stream. If the stream is already playing, this does nothing.";

static char OutputStream_Pause_doc[] = 
"Pause an output stream.";

static char OutputStream_Stop_doc[] = 
"Stop an output stream. The playback position is reset.";

static char OutputStream_Reset_doc[] = 
"Reset the playback position of an output stream.";

#endif
