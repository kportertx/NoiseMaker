#!/usr/bin/env python

import numpy, os
#from distutils.core import setup, Extension
from setuptools import setup, Extension

ext_src = ['pyAudiere.cpp', 'AudioDevice.cpp', 'OutputStream.cpp']
if os.name == 'posix':
    libs = ['audiere-1.9.4', 'stdc++']
    files = []
elif os.name == 'nt':
    libs = []
    files = [('Lib/site-packages', ['..\\..\\vc7\\bin\\release\\audiere.dll'])]
ext = Extension('audiere', ext_src,
                include_dirs=['../../src', '.', numpy.get_include()],
                library_dirs=['../../src'],
                libraries = libs)

setup(name = 'pyaudiere',
    version = '0.2',
    description = 'PyAudiere! A high-level audio interface for Python.',
    url = 'http://www.pyaudiere.org',
    author = 'Christopher Brown',
    author_email = 'c-b /at/ asu.edu',
    maintainer = 'Christopher Brown',
    maintainer_email = 'c-b /at/ asu.edu',
    keywords = 'sound audio wavplay',
    license = 'GPL',
    platforms = 'Win32, Linux',
    ext_modules = [ ext ],
    data_files=files,
    packages = [ '.' ],
    long_description="""\
 PyAudiere is a very flexible and easy to use audio library.
 Available methods allow you to read soundfiles of various formats
 into memory and play them, or stream them if they are large. You
 can pass sound buffers as NumPy arrays of float32's to play
 (non-blocking). You can also create pure tones, square waves, or 
 'on-line' white or pink noise. All of these functions can 
  be utilized concurrently. Sweet!
 """,
    classifiers=[
      "License :: OSI Approved :: GNU General Public License (GPL)",
      "Programming Language :: Python",
      "Operating System :: Microsoft :: Windows",
      "Operating System :: POSIX",
      "Programming Language :: Python",
      "Programming Language :: Python :: 2.5",
      "Programming Language :: Python :: 2.6",
      "Environment :: Console",
      "Development Status :: 4 - Beta",
      "Intended Audience :: Developers",
      "Intended Audience :: Science/Research",
      "Topic :: Multimedia :: Sound/Audio",
      "Topic :: Scientific/Engineering",
    ],
    )
    