#ifndef PY_AUDIO_DEVICE_H
#define PY_AUDIO_DEVICE_H


#include <Python.h>
#include <audiere.h>


extern PyTypeObject audiere_AudioDeviceType;


struct audiere_AudioDeviceObject {
  PyObject_HEAD
  audiere::AudioDevice* device;
};

static char AudioDevice_doc[] = 
"A pyAudiere object representing an audio device. This object\n\
is returned by pyAudiere's open_device method, and it contains\n\
several different methods to create various types of output\n\
streams for playback. Several output streams can be combined\n\
and played back concurrently on the same audio device.\n\n\
Device methods and properties:\n\n\
  create_tone(frequency)\n\
    Creates a tone with the specified frequency and returns an\n\
    OutputStream object that represents it.\n\n\
  create_square(frequency)\n\
    Creates a squarewave with the specified frequency and returns\n\
    an OutputStream object that represents it.\n\n\
  create_white()\n\
    Creates white noise and returns an OutputStream object that \n\
    represents it.\n\n\
  create_pink()\n\
    Creates pink noise and returns an OutputStream object that \n\
    represents it (Pink noise has equal energy per octave).\n\n\
  open_file(filename [, streaming])\n\
    Opens a soundfile from the filename, and returns an OutputStream\n\
    object for it. The streaming parameter sets whether the\n\
    soundfile is loaded into memory before playing, or is streamed.\n\
    It defaults to false (no streaming).\n\n\
    The following file formats are supported: Ogg Vorbis, MP3, FLAC,\n\
    uncompressed WAV, AIFF, MOD, S3M, XM, and IT.\n\n\
  open_array(buffer, fs)\n\
    Opens a sound buffer for playback, and returns an OutputStream\n\
    object for it. The buffer should be a NumPy array of Float32's\n\
    with one or two columns for mono of stereo playback. The second\n\
    parameter is the sampling frequency. Values outside the range\n\
    +-1 will be clipped.\n\n\
  readonly field: name :: string\n\
    The device name (eg., 'directsound', 'winmm', 'oss', etc.)\n\
    ";

static char AudioDevice_CreateTone_doc[] = 
"Returns a pyAudiere output stream object representing a\n\
pure tone. The input argument specifies the frequency.";
  
static char AudioDevice_CreateSquare_doc[] = 
"Returns a pyAudiere output stream object representing a\n\
square wave. The input argument specifies the frequency.";
  
static char AudioDevice_CreateWhiteNoise_doc[] = 
"Returns a pyAudiere output stream object representing\n\
'on line' white noise (flat spectrum).";
  
static char AudioDevice_CreatePinkNoise_doc[] = 
"Returns a pyAudiere output stream object representing\n\
'on line' pink noise (equal energy per octave).";
  
static char AudioDevice_OpenSound_doc[] = 
"Returns a pyAudiere output stream object representing\n\
a sound file. Input argument is the path to the file,\n\
and the second, optional argument is 1 for streaming.";
  
static char AudioDevice_OpenArray_doc[] = 
"Returns a pyAudiere output stream object representing\n\
a sound buffer in memory. Input arguments are an array\n\
of NumPy float32's and the sampling frequency. Values\n\
outside of the range +-1 are clipped.";

#endif
