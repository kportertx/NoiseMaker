#include "pyAudiere.h"

//PyObject* Audiere_GetVersion(PyObject* /*self*/, PyObject* /*args*/) {
//  return PyString_FromString(ver);
//}
//
//PyObject* Audiere_GetLibVersion(PyObject* /*self*/, PyObject* /*args*/) {
//  return PyString_FromString(audiere::GetVersion());
//}

PyObject* Audiere_GetDevices(PyObject* /*self*/, PyObject* /*args*/) {
  PyObject* object = PyDict_New();
  std::vector<audiere::AudioDeviceDesc> devices;
  audiere::GetSupportedAudioDevices(devices);
  for (unsigned i = 0; i < devices.size(); ++i) {
    PyDict_SetItem(object, PyString_FromString(devices[i].name.c_str()),
		   PyString_FromString(devices[i].description.c_str()));
  }
  return object;
}

PyObject* Audiere_OpenDevice(PyObject* /*self*/, PyObject* args) {
  const char* name = 0;
  const char* parameters = 0;

  if (!PyArg_ParseTuple(args, "|ss", &name, &parameters)) {
    return 0;
  }

  audiere::RefPtr<audiere::AudioDevice> device(
    audiere::OpenDevice(name, parameters));
  if (!device) {
    // throw an exception
    PyErr_SetString(PyExc_RuntimeError, "Could not open audio device");
    return 0;
  }

  // create and return python object
  audiere_AudioDeviceObject* object = PyObject_New(
    audiere_AudioDeviceObject, &audiere_AudioDeviceType);
  if (!object) {
    PyErr_SetString(PyExc_RuntimeError, "Could not create Python object");
    return 0;
  }

  object->device = device.get();
  object->device->ref();
  return (PyObject*)object;
}


// module methods
PyMethodDef AudiereMethods[] = {
//  { "get_version", Audiere_GetVersion, METH_VARARGS, Audiere_GetVersion_doc },
//  { "get_libversion", Audiere_GetLibVersion, METH_VARARGS, Audiere_GetLibVersion_doc },
  { "get_devices", Audiere_GetDevices, METH_VARARGS, Audiere_GetDevices_doc },
  { "open_device", Audiere_OpenDevice, METH_VARARGS, Audiere_OpenDevice_doc },
  { 0, 0 }
};

#ifdef WIN32
  #define STDCALL __stdcall
#else
  #define STDCALL
#endif

extern "C" void STDCALL initaudiere() {
  audiere_AudioDeviceType.ob_type  = &PyType_Type;
  audiere_OutputStreamType.ob_type = &PyType_Type;
  
  PyObject *dict, *module, *strd, *strv, *strl;

  module = Py_InitModule("audiere", AudiereMethods);
  dict = PyModule_GetDict(module);
  strd = PyString_FromString(docstring);
  strv = PyString_FromString(ver);
  strl = PyString_FromString(audiere::GetVersion());
  PyDict_SetItemString(dict, "__doc__", strd);
  PyDict_SetItemString(dict, "__version__", strv);
  PyDict_SetItemString(dict, "__libversion__", strl);
  Py_DECREF(strd);
  Py_DECREF(strv);
  Py_DECREF(strl);
  
  import_array();
}
