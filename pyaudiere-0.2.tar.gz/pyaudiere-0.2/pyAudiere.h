#include "Python.h"
#define PY_ARRAY_UNIQUE_SYMBOL _PY_AUDIERE_HANDLE
#include "numpy/arrayobject.h"

#include "AudioDevice.h"
#include "OutputStream.h"

static char ver[] = "0.2";

static char docstring[] =
"PyAudiere! A high-level audio interface for Python!\n\n\
PyAudiere is a very flexible and easy to use audio library.\n\
Available methods allow you to read soundfiles of various formats\n\
into memory and play them, or stream them if they are large. You\n\
can pass sound buffers as NumPy arrays of float32's to play\n\
(non-blocking). You can also create pure tones, square waves, or\n\
on-line white or pink noise.All of these functions can be\n\
utilized concurrently. Sweet!\n\n\
PyAudiere Methods and Properties:\n\n\
 get_devices()\n\
  Returns a python dict containing the available audio devices\n\
  Possible output devices are DirectSound or WinMM in Windows,\n\
  OSS on Linux and Cygwin, and SGI AL on IRIX.\n\n\
 open_device()\n\
  Returns an object that represents an audio device. You can\n\
  specify a device (from one of the devices returned by get_devices)\n\
  or pass no argument for the default device.\n\n\
 readonly field: __version__ :: string\n\
  The pyAudiere version number\n\n\
 readonly field: __libversion__ :: string\n\
  The Audiere library version number\n\n\
 Some examples:\n\n\
  # Open default audio device\n\
  d = audiere.open_device()\n\n\
  # Pink noise in left channel\n\
  p = d.create_pink()\n\
  p.pan = -1\n\
  p.play()\n\n\
  # 500-Hz tone in right channel\n\
  t = d.create_tone(500)\n\
  t.pan = 1\n\
  t.play()\n\
  # make it a 1000-Hz tone instead\n\
  t.pitchshift = 2\n\n\
  # Stream a flac file:\n\
  f = d.open_file('/path/to/file.flac',1)\n\
  f.play()\n\n\
  # Load a sound file into memory, then play it looped:\n\
  l = d.open_file('/path/to/file2.wav')\n\
  l.repeating = 1\n\
  l.play()\n\n\
  #Read in a sound file, do some processing, play it out:\n\
  from scikits.audiolab import wavread\n\
  from scipy.signal import lfilter\n\
  from scipy.signal.filter_design import butter\n\
  buff,fs,enc = wavread('/path/to/file3.wav')\n\
  # Low-pass filter @ 1000 Hz\n\
  b,a = butter(6,1000./(fs/2))\n\
  fb = lfilter(b,a,buff[:,1]) # first channel\n\
  m = d.open_array(fb,fs)\n\
  m.playing = 1\n\
";

//static char Audiere_GetVersion_doc[] =
//"Returns the pyAudiere version number as a string";
//
//static char Audiere_GetLibVersion_doc[] =
//"Returns the Audiere library version number as a string";

static char Audiere_GetDevices_doc[] =
"Returns a python dict containing the available audio devices";

static char Audiere_OpenDevice_doc[] =
"Returns an object that represents an audio device";

