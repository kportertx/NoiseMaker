#include <Python.h>

#include "AudioDevice.h"
#include "OutputStream.h"
#include <algorithm>

#define NO_IMPORT_ARRAY
#define PyArray_API _PY_AUDIERE_HANDLE
#include <numpy/arrayobject.h>


void AudioDevice_dealloc(PyObject* self) {
  ((audiere_AudioDeviceObject*)self)->device->unref();
  PyObject_Del(self);
}


PyObject* NewPyOutputStream(audiere::OutputStream* stream) {
  audiere_OutputStreamObject* object = PyObject_New(
    audiere_OutputStreamObject, &audiere_OutputStreamType);
  if (!object) {
    PyErr_SetString(PyExc_RuntimeError, "Could not create Python object");
    return 0;
  }

  object->stream = stream;
  object->stream->ref();
  return (PyObject*)object;
}


PyObject* AudioDevice_CreateTone(PyObject* self, PyObject* args) {
  audiere_AudioDeviceObject* object = (audiere_AudioDeviceObject*)self;

  double frequency;
  if (!PyArg_ParseTuple(args, "d", &frequency)) {
    return 0;
  }  

  audiere::RefPtr<audiere::OutputStream> stream(
    object->device->openStream(audiere::CreateTone(frequency)));
  if (!stream) {
    PyErr_SetString(PyExc_RuntimeError, "Could not create tone");
    return 0;
  }

  return NewPyOutputStream(stream.get());
}

PyObject* AudioDevice_CreateSquare(PyObject* self, PyObject* args) {
  audiere_AudioDeviceObject* object = (audiere_AudioDeviceObject*)self;

  double frequency;
  if (!PyArg_ParseTuple(args, "d", &frequency)) {
    return 0;
  }  

  audiere::RefPtr<audiere::OutputStream> stream(
    object->device->openStream(audiere::CreateSquareWave(frequency)));
  if (!stream) {
    PyErr_SetString(PyExc_RuntimeError, "Could not create squarewave");
    return 0;
  }

  return NewPyOutputStream(stream.get());
}

  PyObject* AudioDevice_CreateWhiteNoise(PyObject* self, PyObject* args) {
  audiere_AudioDeviceObject* object = (audiere_AudioDeviceObject*)self;

  audiere::RefPtr<audiere::OutputStream> stream(
    object->device->openStream(audiere::CreateWhiteNoise()));
  if (!stream) {
    PyErr_SetString(PyExc_RuntimeError, "Could not create white noise");
    return 0;
  }

  return NewPyOutputStream(stream.get());
}


PyObject* AudioDevice_CreatePinkNoise(PyObject* self, PyObject* args) {
  audiere_AudioDeviceObject* object = (audiere_AudioDeviceObject*)self;

  audiere::RefPtr<audiere::OutputStream> stream(
    object->device->openStream(audiere::CreatePinkNoise()));
  if (!stream) {
    PyErr_SetString(PyExc_RuntimeError, "Could not create pink noise");
    return 0;
  }

  return NewPyOutputStream(stream.get());
}


  PyObject* AudioDevice_OpenSound(PyObject* self, PyObject* args) {
  audiere_AudioDeviceObject* object = (audiere_AudioDeviceObject*)self;
  
  // parse arguments
  const char* filename;
  int streaming = 0;
  if (!PyArg_ParseTuple(args, "s|i", &filename, &streaming)) {
    return 0;
  }

  audiere::RefPtr<audiere::OutputStream> stream(
    audiere::OpenSound(object->device, filename, streaming != 0));
  if (!stream) {
    PyErr_SetString(PyExc_RuntimeError, "Could not open sound file");
    return 0;
  }

  return NewPyOutputStream(stream.get());
}


PyObject* AudioDevice_OpenArray(PyObject* self, PyObject* args) {
  audiere_AudioDeviceObject* object = (audiere_AudioDeviceObject*)self;  

  PyObject *input;
  long int sample_rate = 44100;
  int streaming = 0;
  if (!PyArg_ParseTuple(args, "O|l", &input, &sample_rate))
    return 0;
  PyArrayObject *array = (PyArrayObject *) PyArray_ContiguousFromObject(input, PyArray_DOUBLE, 1, 2);
  unsigned long int n;
  int m;
  
  n = array->dimensions[0];
  m = array->nd;
  short *data = (short *) malloc((n * m) * sizeof(short));
  double t;
  for (unsigned long int i = 0; i < n; i++){
    for (int j = 0; j < m; j++){
      t = * (double *)(array->data + i*array->strides[0] + j*array->strides[1]);
      t = std::max(t, -1.0);
      t = std::min(t, 1.0);
      t = t * 32767;
      data[(i*m)+j] = (short) t;
    };
  };
  
  Py_DECREF(array);
  
  audiere::SampleBuffer* buffer = CreateSampleBuffer(data, n, m, sample_rate, audiere::SF_S16);
  free(data);
  audiere::RefPtr<audiere::OutputStream> stream(audiere::OpenSound(object->device,
								   buffer->openStream(),
								   streaming != 0));
  if (!stream) {
    PyErr_SetString(PyExc_RuntimeError, "Could not open sound buffer");
    return 0;
  }
  
  return NewPyOutputStream(stream.get());
}


PyMethodDef AudioDeviceMethods[] = {
  { "create_tone", AudioDevice_CreateTone, METH_VARARGS, AudioDevice_CreateTone_doc },
  { "create_square", AudioDevice_CreateSquare, METH_VARARGS, AudioDevice_CreateSquare_doc },
  { "create_white", AudioDevice_CreateWhiteNoise,  METH_VARARGS, AudioDevice_CreateWhiteNoise_doc },
  { "create_pink", AudioDevice_CreatePinkNoise,  METH_VARARGS, AudioDevice_CreatePinkNoise_doc },
  { "open_file", AudioDevice_OpenSound,  METH_VARARGS, AudioDevice_OpenSound_doc },
  { "open_array", AudioDevice_OpenArray,  METH_VARARGS, AudioDevice_OpenArray_doc },
  { NULL, NULL }
};


PyObject* AudioDevice_getattr(PyObject* self, char* name) {
  audiere_AudioDeviceObject* object = (audiere_AudioDeviceObject*)self;
  if (strcmp(name, "name") == 0) {
    return PyString_FromString(object->device->getName());
  } else {
    return Py_FindMethod(AudioDeviceMethods, self, name);
  }
}


PyTypeObject audiere_AudioDeviceType = {
  PyObject_HEAD_INIT(NULL)
  0,
  "AudioDevice",
  sizeof(audiere_AudioDeviceObject),
  0,
  AudioDevice_dealloc,
  0,
  AudioDevice_getattr,
  0,   // setattr
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  AudioDevice_doc,
};
